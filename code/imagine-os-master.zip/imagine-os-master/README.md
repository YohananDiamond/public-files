**CLOSED**: I'm not going to work on this anymore. I might return back to it on the future, though.

# ImagineOS
**ImagineOS** is an experimental imaginary OS made just for fun (and maybe learning some things on OS structuring and python development). It tries to make an actual OS structure, but it (probably) doesn't actually work due to missing functions and untested code.

Feel free to drop any ideas or contribute with something on the code.

## Information

Currently its "inspiration language" is Python. If you try to run them, though, I can't guarantee it will actually work, since most of the files probably will have undefined functions and other things.

Older versions of the project can be found on the folder /old/.

## magic()

There's some functions on this repository that are called ``magic()``. It's because there are things that may take too long  to code (or needing to code a real BIOS to do so), so it's a placeholder.
