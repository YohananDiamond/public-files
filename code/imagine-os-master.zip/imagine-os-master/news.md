# 2019

### May 1, 2019

After archiving this repository for some months, I think I want to go back with it. However, I'll try to develop a python-based (also fake) language.

---

# 2018

### December 17, 2018

Ok, so.. I've been looking and the Linux Distro "ImagineOS" is dead. The last version released (20110605) was on June 12, 2011, so I don't need to worry about many people thinking this repo is about that distribution.

### December 14, 2018

So, I've been searching on the internetand found out that there is a Linux Distro with the name of ImagineOS. I probably will need to change the name of my distribution to something different to not to cause confusion with it.
