# Desktop Manager. For now it's a TUI (Text User Interface), since it's simpler to implement.
# TODO: screenapi.py
import screenapi
import os

alias_dict = {} # Empty dict for adding the aliases later
menu = 0 # Placeholder to make the menu variable universal

def main():
    menu = screenapi.obj_menu(0, 0, screenapi.screen_x, 20) # TODO: obj_menu(PosX, PosY, SizeX, SizeY)
    # TODO: screen_x, screen_yp, menu.ls
    menu.ls.append('Main') # Adds an item to the menu items list.
    menu.ls.append('Alias')
    # TODO: Create a way to add sub-items
    # TODO: Add menu.ls.append()
    alias_file = open(os.path.normpath(os.path.getcwd(), '/../../user-data/file.txt'),'w+')
    alias_file = open(os.path.normpath(os.path.getcwd(), '/../../user-data/file.txt'),'r')
    for line in alias_file:
        # TODO: Add code to scan the lines and add their values to a dict or list. The keys should be 'Title' and 'Action'.
    alias_file.close()
    # TODO: Add code to add the items from the dict to the 'Alias' menu and assign their actions.

main() # Launch the program's main
