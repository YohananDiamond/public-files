# Text User Interface Management
def cls():
    for char in ram.search('screen_tui'):
        del char
    ram.setval('tui_ypos', 0)
