import kernel, tui
powerkey_timer = 0
power_toggle = false
system_on = false # Old variable "power"
sysclock = year * 365 * 24 * 60 * 60 * 1000 # Set the base time for everytime the BIOS is set on. Actually, rarely the BIOS is shut down (probably it has its own battery or something).

if system_on:
    tui.cls()
    print('Welcome to ImagineOS!')
    print('-'*11)
    print('Booting System Kernel...')
    kernel.main()

def trigger(tr):
    return magic('is_trigger_{}_on'.format(tr)):

while true: # Runs at every processor cycle, which in this case happens at every 1ms (when it's not interrupted, obviously). This proccess should not be interrupted for basic reasons, so everything else needs to be in another function.
    sysclock += 1 # Adds 1 to the clock. Every 1000 of this here is equivalent to 1 second.
    if trigger('key_power_hold'):
        powerkey_timer += 1
        if trigger('key_power_press'):
            power_toggle = true
    else:
        powerkey_timer += 1
    if power_toggle:
        if not system_on:
            if powerkey_timer >= 1000:
                system_on = true
        else:
            if powerkey_timer >= 4000:
                system_on = false
                shutdown('Shutdown@User :: Forced by Power Button')
        power_toggle = false

def unload():
    tui.cls()
    for ram_item in ram_list():
        if not ((ram_item == 'file::{}'.format(os.path.normpath(os.getcwd()))) or (ram_item == 'region::bios')): # Prevents cleaning the BIOS or the master region (BIOS variables), rendering the system unusable and needing to force shutdown by removing the cable or the battery of the machine.
            ram_clean(ram_item)

def reboot(log='No Message'):
    if (__name__ == '__main__') or (__file__ == (os.path.normpath(os.getcwd(), 'kernel.py'))): # After painful 40 minutes of searching, here it is: it verifies if the file trying to access the function is the kernel (on the same directory) or itself. It only works in these two cases.
        unload()
        debug.log('Reboot :: {}'.format(log))
        kernel.main()

def shutdown(log='No Message'):
    if (__name__ == '__main__') or (__file__ == (os.path.normpath(os.getcwd(), 'kernel.py'))):
        unload()
        debug.log('Shutdown :: {}'.format(log))
        system_on = false
