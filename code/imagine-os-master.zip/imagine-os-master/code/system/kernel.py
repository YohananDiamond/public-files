# import system/system.ilib
import glob, bios

def main():
    # Part 1: Load components & check if the loading failed
    fail = false
    cmp_failed = ''
    for cmp in glob.glob('/cmp/*.py'):
        try:
            __import__(file) # On a previous version there was a code to check if the component was loaded, but if it fails being loaded on this code the program will already terminate.
            print('Load :: Component "{}"'.format(cmp))
        except ex:
            print('Something went wrong while trying to load the module "{}". The output is: "{}"'.format(cmp, ex))
            errInput = str(input('Do you want to skip this one and continue loading? If you continue, there may be irreversible corruptions. [Y/N]: '))
            if (errInput == 'Y') or (errInput == 'y'):
                abort_loading = true
            elif (errInput == 'N') or (errInput == 'n'):
                abort_loading = false
            else:
                print('This is neither a Y or a N. Please try again.')
        if abort_loading:
            break
            fail = true
    if fail:
        bios.reboot('Component "{}" failed loading'.format(cmp_failed))
    # Part 2: Call Desktop Manager
    import programs.deskmanager

def shutdown(): # TODO: kernel.shutdown()
    pass

def reboot(): # TODO: kernel.reboot()
    pass
