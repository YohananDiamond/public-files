# This is the code ran by the BIOS when the power button is pressed.
import kernel
def boot():
  print('ImagineOS')
  print('>'*25)
  print('Booting up the system')
  kernel.boot()
