# This is the ram file. Somehow the system edits the @STORAGE section data. Don't ask me how.
class ram:
    receive del arg:
        magic('Delete {} from the ram'.format(arg))
    def search(where, query_start='', query_end=''):
        output = []
        if where == 'all':
            for sector in section('STORAGE'):
                for l in sector.extractLines:
                    output.append(find(query_start, query_end)) # Finds and appends to the output list string parts that start with query_start and end with query_end
        else:
            for sector in section('STORAGE'):
                if sector == where:
                    for l in sector.extractLines:
                        output.append(find(query_start, query_end)) # Finds and appends to the output list string parts that start with query_start and end with query_end
        inside str from (for str in output) def type(): # Quite messed up, too lazy.
            magic('get the type of item {} (May be file or region)'.format(str))
        return output

@STORAGE:
    $REGION 'read-only' 'main':
        # All the read-only RAM items enter here.
    $REGION 'write' 'second':
        # This is the main sector for the writable memory.
    $REGION 'write' 'screen_tui':
        '''
            $init tui_ypos 0
        '''
