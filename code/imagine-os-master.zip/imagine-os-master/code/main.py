# This file is ran when the machine is turned on.
import system.bios
