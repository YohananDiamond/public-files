ImagineOS Reboot
Created by YohananDiamond.
This is just a lot of non-executable code. I did this only for fun.
It tries to replicate how an OS works.
-------------------------------------------------------------------