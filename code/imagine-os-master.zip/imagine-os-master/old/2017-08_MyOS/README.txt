Hello, welcome to my OS!
It doesn't work but it's cool anyway!

.lcf - Language Comprehension File
.df - DataFile
.asm+ - Assembly+
.class - Class File (Essential for applications)