# File Formats
This file lists and defines all unknown file formats used here. They may have an actual program use somewhere.
 - `.isf` - System File (components, kernel etc.)
 - `.idt` - Data File
 - `.ipr` - Program File (executable)
 - `.ilib` - Library File (like .dll)
