# ImagineOS Code Guidelines
Version: 0.4.2

## Commands
- `//` - Comment
- `/* */` - Alt. Comment
- `$` - Command Prefix [use: `$command`]
  - `$add` - Create a new value [use: `$add(value name, type)`]
  - `$set` - Define a value to something [use: `$set value = something`]
  - `$print` - Show a text on the screen [use: `$print text`] [or: `$print(text)`]
  - `$exec` - Executes the code of a file [use: `$exec filepath`]
  - `$cls` - Clears the screen [use: `$cls`]
  - `$fn` - Calls a function [use: `fn(path).function_name(arg1, arg2)`]
    - Note: If the 'path' field is empty, it's considered that the function is local (is on that file).
    - `(arg1, arg2)` - See the @fn condition to more info.
- `+` - Instant Commands
  - `+ival` - Create an instant value (not stored in memory) [use: `+ival(value, type)`]
  - `+checkloaded` - Check if something is loaded into the RAM [use: `+checkloaded(filepath)`]
- `@` - Conditions [use: `@condition`]
  - `@if` - Do something (one time only) if it's true. [use: `@if boolean:`]
  - `@foreach` - Executes the related code for each item picked on this condition. [use: `@foreach(condition):`]
    - `x as y in z` - Pick all items of the value **y** in the namespace **z**. These items will be named **x**.
    - `x as y` - The same thing as above, but sometimes it's not needed to specify z.
  - `@while` - Do something every CPU clock if it's not true [use: `@while(boolean):`]
  - `@whilever` - Do only what's in here repeatedly until it's true (may crash the machine), pausing all the other activities [use: `@whilever(boolean):`]
  - `@clock` - Executes the specified code every CPU cycle. [use: `@clock:`]
  - `@tr` - Executes the code if a certain trigger is on. [use: `@tr(trigger_name):`]
  - `@tr!` - Executes the code if a certain trigger is not on. [use: `@tr!(trigger_name):`]
  - `@fn` - Creates a anchor for a function (trigger called by command). For more info, go to the command $fn. [use: `@fn(public/private/restricted(allowedfile, allowedfile2) fname(arg1, arg2)`]
    - `public` - Any file can call this function.
    - `private` - Only commands in this file can call this function.
    - `restricted` - Only determined files can call this function. [use: `restricted(allowedfile, allowedfile2...)`]
    - `fname` - The function name
    - `(arg1 type, arg2 type)` - The arguments (as values) that will be needed to execute the function (you can add, for example, strings specified on the $fn command that need to be used on the function code). 

## Value Types
  - `str` - String
  - `strls` - String List
  - `int` - Integer
  - `intls` - Integer List
  - `float` - Float Number
  - `ftls` - Float Number List
  - `bool` - Boolean
  - `obj` - Object

## Extras
### String Definition Method
To define a string, it's needed to put the value between apostrophes (`''`) or quotation marks (`""`).
### How to define values of a string, integer or float list
The values in the lists are separated by semicolons (`;`) [use: `a; b; c`]
### Create a list of integers/floats with all numbers between two values
This may sound a bit complicated. Look at the formula below:
 - `(x; y) # z`


This will make the list contain all values that goes from x to y, while adding z. For example, let's use the example below:
> **INPUT:** (0; 10) # 2

> **OUTPUT:** 0; 2; 4; 6; 8; 10;


As seen above, it will create a list starting with zero and will stop when the number is greater or equal to 10.
You can also make this with negative numbers:
> **INPUT:** (-2; -6) # -1

> **OUTPUT:** -2; -3; -4; -5; -6;


Or with float numbers:
> **INPUT:** (0.0; 2.5) # 0.5

> **OUTPUT:** 0.0; 0.5; 1.0; 1.5; 2.0; 2.5;


But there will be an error if you try to decrease (**z** being -1) while the goal point (**y**) is greater than the starting point (**x**):
> **INPUT:** (5; 20) # -1

> **OUTPUT:** 5; <ERROR>

Or with the reverse of this.
> **INPUT:** (-10; -20) # 10

> **OUTPUT:** -10; <ERROR>

### Create a list of strings with a similar method as above.
- [ ] Complete this method.
