declarate lang = "ImagineSharp"

private class main {
	InitializeComponent(
		Find(Language = lang)
		);
	print("Welcome to ImagineOS!");
	print("₢PXNS 2017");
	print("Booting kernel");
	functions.bootkernel();
	print("Kernel booted!");
	print("Booting components...");
	For each cmp as System.Component in System.Path("C:/boot/components/") {
		System.loadcomponent(cmp);
		If output = suceed {
			print("Loaded " + cmp.getfilename.withextension);
			If cmp = lastItem{
				functions.bootscreen();
			}
			
		} /Else {
			print("An error has ocurred! Press enter to try again.")
			<Handle event keypress="ENTER","System.Restart();">
		}
	}
};

public namespace System {
	dim Component as isolated.name{};
	dim Path as isolated.string{ps as string};

	public function Restart(){
		My.BIOS.UnloadEverything();
		My.BIOS.Reboot();
	}
}

public class functions {
	public function bootkernel(){
		<load code{'
			My.BIOS.Load();
			'}
	};
	public function bootscreen(){
		obj icon = new image("C:/boot/resources/logo.bimg");
		obj pb = new progressBar();
		dim code = new string(from "C:/boot/boot.bin");
		point ic = New Point(50%Screen.width-50%icon.width,50%Screen.height-50%icon.height);
		My.Screen.Draw(icon,ic);
		My.Screen.Draw(pb, ic - New Point(0,30))
		code.analyze();
		for each codestring as string#from codeline in code by codeverse.languagedatabase.binary {
			runcode(codestring);
		};
		If output = suceed {
			cls();
			print("Loaded!");
			wait(3); /* 30 is the seconds */
			cls();
			start("C:/imagine/login.cs")
		} /Else {
			cls();
			print("An error ocurred!")
			wait(3);
			System.Restart();
		}
	}
	public function loadcomponent(cmp as component){
		cmp.analyze();
		for each codestring as string#from codeline in cmp by codeverse.languagedatabase.imagineBasic {
			runcode(codestring);
		};
	};
}