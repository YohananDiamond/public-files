declarate lang = "ImagineSharp"

private class main {
	InitializeComponent();
	If database.users.count > 0 {
		Functions.GotoLogin();
	} /Else {
		Functions.FirstSetup();
	}

}

public class Functions {
	public function GotoLogin() {
		private schematic login(type="markup") {
			<BLOCK align="centerScreen"/
				<IMG from="C:/users/mainUser/protected/photo.png" mode="circle" align="center">
				<ITEM type="textbox" id="passbox" align="center">
				<Item type="button" align="center" onclick="functions.Login();" text="OK">
			/END BLOCK>
		}
	}
	public function FirstSetup() {

	}
	public function Login() {
		str password = ITEM#passbox text
		if password = string.from("C:/Users/mainUsers/protected/password.png",firstLine) {
			cls();
			My.Desktop.Show();
		} /Else {
				MsgBox("Wrong Pass! Please insert the correct.")
		}

	}
}