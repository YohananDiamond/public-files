## Old Files Folder
This folder was created for storing old versions of the ImagineOS. They are messy and most of them probably aren't even similar to the current coding guidelines.
